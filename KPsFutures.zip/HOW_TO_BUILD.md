# KPsFutures - Android app (NIFTY/BANKNIFTY/SENSEX + stock futures)

1. GitHub par naya Private repo banao, naam: KPsFutures
2. KPsFutures.zip upload karo (zip ko kholna nahi) -> Commit
3. .github/workflows/build.yml banao, build.yml ka text paste karo -> Commit
4. Actions me hara tick aane tak ruko (10-20 min) -> Releases me KPsFutures.apk -> phone me install

Dry-run by default ON. Zerodha redirect URL: http://127.0.0.1:5000/  Dashboard port 5054.
SL/Target app ke andar chalte hain (broker side nahi). Futures me loss margin se zyada ho sakta hai.
