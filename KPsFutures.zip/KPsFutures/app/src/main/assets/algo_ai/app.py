"""KP's Futures - dashboard server (Flask). Dashboard: http://127.0.0.1:5054"""
import os
import secrets
import sys
import threading
import webbrowser

from flask import Flask, jsonify, request, Response

import futures_core as fc

PORT = 5054
HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN = secrets.token_urlsafe(24)       # page <-> API token: other apps on the phone cannot place trades

app = Flask(__name__, static_folder=None)
engine = None


def _engine():
    global engine
    if engine is None:
        engine = fc.Engine()
        engine.start()
    return engine


@app.before_request
def _guard():
    host = (request.host or "").split(":")[0]
    if host not in ("127.0.0.1", "localhost"):
        return Response("forbidden", 403)
    if request.path.startswith("/api/") and request.headers.get("X-KP-Token") != TOKEN:
        return Response("forbidden", 403)


@app.after_request
def _nocache(resp):
    resp.headers["Cache-Control"] = "no-store"
    return resp


@app.route("/")
def index():
    with open(os.path.join(HERE, "templates", "index.html"), encoding="utf-8") as f:
        html = f.read().replace("__TOKEN__", TOKEN)
    return Response(html, mimetype="text/html")


def _ok(**kw):
    d = {"ok": True}
    d.update(kw)
    return jsonify(d)


def _err(msg, code=400):
    return jsonify({"ok": False, "error": str(msg)}), code


def _run(fn, *a, **kw):
    try:
        return _ok(result=fn(*a, **kw))
    except fc.TradeError as exc:
        return _err(exc)
    except Exception as exc:            # noqa: BLE001
        _engine().log("Unexpected error: %r" % exc)
        return _err("Unexpected error: %s" % exc, 500)


@app.route("/api/state")
def state():
    return jsonify(_engine().snapshot())


@app.route("/api/settings", methods=["POST"])
def settings():
    d = request.get_json(force=True, silent=True) or {}
    confirm = bool(d.pop("confirm_live", False))
    return _run(_engine().update_settings, d, confirm)


@app.route("/api/login/start", methods=["POST"])
def login_start():
    return _run(_engine().start_login)


@app.route("/api/login/paste", methods=["POST"])
def login_paste():
    d = request.get_json(force=True, silent=True) or {}
    return _run(_engine().complete_login, d.get("value", ""))


@app.route("/api/logout", methods=["POST"])
def logout():
    return _run(_engine().logout)


@app.route("/api/trade", methods=["POST"])
def trade():
    d = request.get_json(force=True, silent=True) or {}
    return _run(_engine().open_position, d.get("side"), d.get("underlying"), d.get("lots"),
                d.get("sl_points"), d.get("target_points"), bool(d.get("confirm_live")))


@app.route("/api/exit", methods=["POST"])
def exit_():
    return _run(_engine().close_position, "MANUAL")


def main(open_browser=False):
    from werkzeug.serving import make_server
    _engine()
    srv = make_server("127.0.0.1", PORT, app, threaded=True)
    url = "http://127.0.0.1:%d/" % PORT
    print("KP's Futures dashboard: " + url, flush=True)
    if open_browser:
        threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    srv.serve_forever()


if __name__ == "__main__":
    main(open_browser=True)
