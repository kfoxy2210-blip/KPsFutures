"""
KP's Futures - core engine.

One position at a time, in the nearest (or next) monthly FUTURES contract of an index.
  * dry_run ON  : nothing is sent to Zerodha. Fills are simulated at the live best bid/ask (LTP if no depth).
  * dry_run OFF : real MARKET / MIS orders (market_protection=auto), fills confirmed with Zerodha's order status.
Stop-loss / target / trailing / force-exit are SOFTWARE exits that run in this program: if the phone or
this app stops, there is NO stop at the broker.

All files (settings.json, futures_token.json, futures_state.json, futures_trades.json) live in the
working folder (the app's private folder on Android).
"""
import datetime as dt
import http.server
import json
import os
import re
import threading
import time
import traceback
import urllib.parse
import uuid
import webbrowser
from collections import deque

try:
    from kiteconnect import KiteConnect
except Exception:                      # noqa: BLE001 - tests inject a fake
    KiteConnect = None

IST = dt.timezone(dt.timedelta(hours=5, minutes=30))


def now():
    """Current IST time, independent of the machine's time zone."""
    return dt.datetime.now(IST)


BFO_NAMES = {"SENSEX", "BANKEX"}
UNDERLYINGS = ["NIFTY", "BANKNIFTY", "SENSEX", "FINNIFTY", "MIDCPNIFTY", "BANKEX"]
# Starting values only (points). Change freely in the app.
SUGGESTED = {
    "NIFTY": (40, 80), "BANKNIFTY": (100, 200), "SENSEX": (120, 240),
    "FINNIFTY": (40, 80), "MIDCPNIFTY": (30, 60), "BANKEX": (100, 200),
}
NAME_RE = re.compile(r"^[A-Z0-9&-]{1,20}$")      # index or F&O stock name, e.g. RELIANCE, M&M, BAJAJ-AUTO
REDIRECT_PORT = 5000
HARD_MAX_LOTS = 10

DEFAULTS = {
    "api_key": "",
    "api_secret": "",
    "dry_run": True,
    "underlying": "NIFTY",
    "expiry_pick": "near",          # near = nearest expiry, next = the one after
    "lots": 1,
    "max_lots": 2,
    "sl_points": 40,
    "target_points": 80,            # 0 = no target
    "trailing": False,
    "trail_start": 30,              # profit (points) at which trailing begins
    "trail_gap": 20,                # stop follows the best price at this distance
    "entry_cutoff": "15:00",        # no NEW entries after this time
    "force_exit_time": "15:15",     # open position is closed at this time
    "enforce_hours": True,          # dry-run only: False lets you test after market hours
    "max_daily_loss": 5000,         # Rs; blocks new entries once reached (0 = off)
}


class TradeError(Exception):
    pass


def _atomic_write(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, default=str)
    os.replace(tmp, path)


def _read_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:                  # noqa: BLE001
        return default


def _hhmm(s, fallback):
    try:
        h, m = str(s).split(":")
        return dt.time(int(h), int(m))
    except Exception:                  # noqa: BLE001
        h, m = fallback.split(":")
        return dt.time(int(h), int(m))


class Engine:
    def __init__(self, data_dir=None):
        self.dir = data_dir or os.getcwd()
        self.lock = threading.RLock()      # short: protects state shown in the UI
        self.op_lock = threading.RLock()   # long: serialises entry / exit / SL checks (network calls)
        self._tlock = threading.Lock()
        self.logs = deque(maxlen=300)
        self.settings = dict(DEFAULTS)
        self.settings.update({k: v for k, v in _read_json(self._p("settings.json"), {}).items() if k in DEFAULTS})
        self.kite = None
        self.logged_in = False
        self.user = None
        self.login_error = None
        self._login_thread = None
        self._last_call = 0.0
        self._instr = {}               # exchange -> (date, list)
        self.contract = {}             # underlying -> contract dict
        self.preview = {}              # last price of the watched contract
        self.position = _read_json(self._p("futures_state.json"), {}).get("position")
        self.trades = _read_json(self._p("futures_trades.json"), [])
        self.price_ok_at = time.time()
        self.warn = None
        self._reconciled = False
        self._stop = False
        self._thread = None
        if self.position:
            self.log("Restored open position %s %s from the last run - SL/target will resume after Zerodha login." % (
                self.position["side"], self.position["tradingsymbol"]))
        self._init_kite()
        self._load_token()

    # ------------------------------------------------------------------ helpers
    def _p(self, name):
        return os.path.join(self.dir, name)

    def log(self, msg):
        line = "%s  %s" % (now().strftime("%H:%M:%S"), msg)
        self.logs.append(line)
        print("[futures] " + line, flush=True)

    def _save_state(self):
        _atomic_write(self._p("futures_state.json"), {"position": self.position})

    def _save_trades(self):
        _atomic_write(self._p("futures_trades.json"), self.trades[-500:])

    def _throttle(self):
        """Zerodha allows ~1 quote/ltp request per second."""
        with self._tlock:
            wait = 1.05 - (time.time() - self._last_call)
            if wait > 0:
                time.sleep(wait)
            self._last_call = time.time()

    # ------------------------------------------------------------------ settings
    def public_settings(self):
        s = dict(self.settings)
        s["has_secret"] = bool(s.pop("api_secret", ""))
        return s

    def update_settings(self, d, confirm_live=False):
        und = str(d.get("underlying", "")).strip().upper()
        if und and und != self.settings["underlying"] and self.logged_in and NAME_RE.match(und):
            try:
                self.get_contract(und)
            except TradeError:
                raise TradeError("No futures contract found for %s. Check the name (stock futures use the NSE symbol, e.g. RELIANCE)." % und)
            except Exception as exc:   # noqa: BLE001
                raise TradeError("Could not look up %s: %s" % (und, exc))
        with self.lock:
            new = dict(self.settings)
            for k, v in d.items():
                if k not in DEFAULTS:
                    continue
                if k == "api_secret" and not v:
                    continue           # blank = keep the saved secret
                typ = type(DEFAULTS[k])
                try:
                    if typ is bool:
                        v = bool(v)
                    elif typ is int:
                        v = int(float(v))
                    elif typ is str:
                        v = str(v).strip()
                except Exception:      # noqa: BLE001
                    raise TradeError("Bad value for %s" % k)
                new[k] = v
            new["underlying"] = new["underlying"].strip().upper()
            if not NAME_RE.match(new["underlying"]):
                raise TradeError("Underlying must be an index or F&O stock name, e.g. NIFTY or RELIANCE.")
            if new["expiry_pick"] not in ("near", "next"):
                raise TradeError("expiry_pick must be near or next")
            new["max_lots"] = max(1, min(HARD_MAX_LOTS, new["max_lots"]))
            new["lots"] = max(1, min(new["max_lots"], new["lots"]))
            for k in ("sl_points", "trail_start", "trail_gap"):
                if new[k] <= 0:
                    raise TradeError("%s must be above 0" % k)
            if new["target_points"] < 0 or new["max_daily_loss"] < 0:
                raise TradeError("target_points / max_daily_loss cannot be negative")
            for k in ("entry_cutoff", "force_exit_time"):
                try:
                    h, m = str(new[k]).split(":")
                    dt.time(int(h), int(m))
                except Exception:      # noqa: BLE001
                    raise TradeError("%s must look like 15:15" % k)
            if self.settings["dry_run"] and not new["dry_run"]:
                if not confirm_live:
                    raise TradeError("Switching to LIVE needs confirmation.")
                if self.position:
                    raise TradeError("Close the open (simulated) position before switching to LIVE.")
                self.log("*** LIVE MODE ENABLED - real orders will be placed ***")
            if not self.settings["dry_run"] and new["dry_run"]:
                if self.position and not self.position.get("dry_run"):
                    raise TradeError("Close the open LIVE position before switching to dry-run.")
                self.log("Dry-run mode enabled.")
            key_changed = (new["api_key"] != self.settings["api_key"])
            self.settings = new
            _atomic_write(self._p("settings.json"), self.settings)
            if key_changed:
                self._init_kite()
                self.logged_in = False
                self.user = None
            return self.public_settings()

    # ------------------------------------------------------------------ zerodha session
    def _init_kite(self):
        key = self.settings.get("api_key")
        if key and KiteConnect is not None:
            self.kite = KiteConnect(api_key=key)
        else:
            self.kite = None

    def _load_token(self):
        t = _read_json(self._p("futures_token.json"), {})
        if not self.kite or not t.get("access_token"):
            return
        if t.get("date") != now().strftime("%Y-%m-%d") or t.get("api_key") != self.settings.get("api_key"):
            return
        try:
            self.kite.set_access_token(t["access_token"])
            prof = self.kite.profile()
            self.logged_in = True
            self.user = prof.get("user_name") or prof.get("user_id")
            self.log("Re-used today's Zerodha login (%s)." % self.user)
        except Exception as exc:       # noqa: BLE001
            self.logged_in = False
            self.log("Saved login is no longer valid: %s" % exc)

    def login_url(self):
        if not self.settings.get("api_key") or not self.settings.get("api_secret"):
            raise TradeError("Enter and save API key + secret first.")
        if self.kite is None:
            self._init_kite()
        if self.kite is None:
            raise TradeError("kiteconnect library missing (pip install kiteconnect).")
        return self.kite.login_url()

    def start_login(self):
        """Returns the Zerodha login URL and waits (in a thread) for the redirect on 127.0.0.1:5000."""
        url = self.login_url()
        self.login_error = None
        engine = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):          # noqa: N802
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                tok = (q.get("request_token") or [None])[0]
                ok = False
                msg = "No request_token in this address."
                if tok:
                    try:
                        engine.complete_login(tok)
                        ok, msg = True, "Login successful. You can go back to the app."
                    except Exception as exc:    # noqa: BLE001
                        msg = "Login failed: %s" % exc
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(("<html><body style='font-family:sans-serif;padding:24px'><h3>%s</h3></body></html>" % msg).encode())
                if ok:
                    threading.Thread(target=self.server.shutdown, daemon=True).start()

            def log_message(self, *a):
                pass

        try:
            srv = http.server.ThreadingHTTPServer(("127.0.0.1", REDIRECT_PORT), Handler)
        except OSError:
            # Another KP app is using port 5000 right now - the user can still paste the redirect address.
            self.log("Port %d busy (another app is logging in?). Use 'paste redirect address' instead." % REDIRECT_PORT)
            srv = None
        if srv:
            def run():
                srv.timeout = 1
                end = time.time() + 240
                th = threading.Thread(target=srv.serve_forever, daemon=True)
                th.start()
                while time.time() < end and th.is_alive():
                    time.sleep(0.5)
                try:
                    srv.shutdown()
                except Exception:      # noqa: BLE001
                    pass
                srv.server_close()
            self._login_thread = threading.Thread(target=run, daemon=True)
            self._login_thread.start()
        try:
            webbrowser.open(url)
        except Exception:              # noqa: BLE001
            pass
        return url

    def complete_login(self, token_or_url):
        s = str(token_or_url).strip()
        if "request_token=" in s:
            s = (urllib.parse.parse_qs(urllib.parse.urlparse(s).query).get("request_token") or [""])[0]
        if not s:
            raise TradeError("Could not find request_token in what you pasted.")
        if self.kite is None:
            self._init_kite()
        if self.kite is None:
            raise TradeError("kiteconnect library missing.")
        data = self.kite.generate_session(s, api_secret=self.settings["api_secret"])
        self.kite.set_access_token(data["access_token"])
        _atomic_write(self._p("futures_token.json"), {
            "access_token": data["access_token"], "api_key": self.settings["api_key"],
            "date": now().strftime("%Y-%m-%d")})
        self.logged_in = True
        self.user = data.get("user_name") or data.get("user_id")
        self.login_error = None
        self.price_ok_at = time.time()
        self.log("Zerodha login OK (%s)." % self.user)

    def logout(self):
        try:
            os.remove(self._p("futures_token.json"))
        except OSError:
            pass
        self.logged_in = False
        self.user = None
        self.log("Logged out (saved token removed).")

    def _auth_failed(self, exc):
        name = type(exc).__name__
        if name in ("TokenException", "PermissionException") or "access_token" in str(exc).lower():
            if self.logged_in:
                self.logged_in = False
                self.login_error = "Zerodha session expired - log in again."
                self.log("!!! Zerodha session expired. SL/target are NOT running until you log in again.")
            return True
        return False

    # ------------------------------------------------------------------ contracts
    def _instruments(self, exchange):
        today = now().date()
        cached = self._instr.get(exchange)
        if cached and cached[0] == today:
            return cached[1]
        self._throttle()
        rows = self.kite.instruments(exchange)
        self._instr[exchange] = (today, rows)
        return rows

    def find_contract(self, underlying):
        if not self.logged_in:
            raise TradeError("Log in to Zerodha first.")
        exch = "BFO" if underlying in BFO_NAMES else "NFO"
        today = now().date()
        futs = []
        for r in self._instruments(exch):
            if r.get("instrument_type") != "FUT" or r.get("name") != underlying:
                continue
            exp = r.get("expiry")
            if isinstance(exp, str):
                exp = dt.date.fromisoformat(exp[:10])
            elif isinstance(exp, dt.datetime):
                exp = exp.date()
            if exp and exp >= today:
                futs.append((exp, r))
        if not futs:
            raise TradeError("No %s futures contract found." % underlying)
        futs.sort(key=lambda x: x[0])
        idx = 1 if (self.settings["expiry_pick"] == "next" and len(futs) > 1) else 0
        exp, r = futs[idx]
        c = {"underlying": underlying, "exchange": exch, "tradingsymbol": r["tradingsymbol"],
             "token": r.get("instrument_token"), "lot_size": int(r["lot_size"]),
             "expiry": exp.isoformat(), "tick_size": float(r.get("tick_size") or 0.05)}
        self.contract[underlying] = c
        return c

    def get_contract(self, underlying):
        c = self.contract.get(underlying)
        if c and c.get("_day") == now().date().isoformat() and c.get("_pick") == self.settings["expiry_pick"]:
            return c
        c = self.find_contract(underlying)
        c["_day"] = now().date().isoformat()
        c["_pick"] = self.settings["expiry_pick"]
        return c

    # ------------------------------------------------------------------ prices
    def ltp(self, c):
        key = "%s:%s" % (c["exchange"], c["tradingsymbol"])
        self._throttle()
        data = self.kite.ltp([key])
        return float(data[key]["last_price"])

    def quote(self, c):
        key = "%s:%s" % (c["exchange"], c["tradingsymbol"])
        self._throttle()
        q = self.kite.quote([key])[key]
        depth = q.get("depth") or {}
        bid = ask = 0.0
        try:
            bid = float(depth["buy"][0]["price"])
            ask = float(depth["sell"][0]["price"])
        except Exception:              # noqa: BLE001
            pass
        return float(q["last_price"]), bid, ask

    # ------------------------------------------------------------------ orders
    def _place(self, c, side, qty):
        kw = dict(variety="regular", exchange=c["exchange"], tradingsymbol=c["tradingsymbol"],
                  transaction_type=side, quantity=qty, product="MIS", order_type="MARKET",
                  tag="KPFUT")
        kw["market_protection"] = getattr(self.kite, "MARKET_PROTECTION_AUTO", -1)
        return self.kite.place_order(**kw)

    def _confirm_fill(self, order_id, timeout=15):
        t0 = time.time()
        st = "UNKNOWN"
        while time.time() - t0 < timeout:
            hist = self.kite.order_history(order_id)
            last = hist[-1] if hist else {}
            st = last.get("status", "UNKNOWN")
            if st == "COMPLETE":
                return float(last["average_price"])
            if st in ("REJECTED", "CANCELLED"):
                raise TradeError("Order %s: %s" % (st, last.get("status_message") or "no reason given"))
            time.sleep(0.7)
        try:                           # not confirmed - try to cancel, then look one last time
            self.kite.cancel_order("regular", order_id)
        except Exception:              # noqa: BLE001
            pass
        time.sleep(1.0)
        hist = self.kite.order_history(order_id)
        last = hist[-1] if hist else {}
        if last.get("status") == "COMPLETE":
            return float(last["average_price"])
        raise TradeError("Order not confirmed in %ds (status %s). CHECK KITE before retrying." % (timeout, last.get("status", st)))

    def _margin_check(self, c, side, qty):
        try:
            need = self.kite.order_margins([{
                "exchange": c["exchange"], "tradingsymbol": c["tradingsymbol"], "transaction_type": side,
                "variety": "regular", "product": "MIS", "order_type": "MARKET", "quantity": qty}])
            required = float(need[0]["total"])
            self._throttle()
            avail = float(self.kite.margins("equity")["available"]["live_balance"])
        except Exception as exc:       # noqa: BLE001
            raise TradeError("Could not check margin (%s). Entry blocked for safety." % exc)
        if required > avail:
            raise TradeError("Margin needed Rs %.0f but available Rs %.0f." % (required, avail))
        return required, avail

    # ------------------------------------------------------------------ trading
    def day_pnl(self, dry):
        today = now().strftime("%Y-%m-%d")
        return sum(t.get("pnl_rupees", 0) for t in self.trades
                   if str(t.get("exit_time", ""))[:10] == today and bool(t.get("dry_run")) == bool(dry))

    def _in_hours(self, dry):
        n = now()
        if n.weekday() >= 5:
            return False, "Market is closed (weekend)."
        start, cutoff = dt.time(9, 15), _hhmm(self.settings["entry_cutoff"], "15:00")
        if start <= n.time() < cutoff:
            return True, ""
        return False, "New entries are allowed only between 09:15 and %s." % self.settings["entry_cutoff"]

    def open_position(self, side, underlying=None, lots=None, sl_points=None, target_points=None, confirm_live=False):
        side = str(side).upper()
        if side not in ("BUY", "SELL"):
            raise TradeError("side must be BUY or SELL")
        with self.op_lock:
            s = self.settings
            dry = s["dry_run"]
            underlying = underlying or s["underlying"]
            underlying = str(underlying).strip().upper()
            if not NAME_RE.match(underlying):
                raise TradeError("Unknown underlying.")
            lots = int(lots or s["lots"])
            sl_points = float(sl_points if sl_points is not None else s["sl_points"])
            target_points = float(target_points if target_points is not None else s["target_points"])
            if not self.logged_in:
                raise TradeError("Log in to Zerodha first.")
            if self.position:
                raise TradeError("A position is already open. Exit it first.")
            if lots < 1 or lots > s["max_lots"]:
                raise TradeError("Lots must be 1 to %d (max_lots in Settings)." % s["max_lots"])
            if sl_points <= 0:
                raise TradeError("Stop-loss points must be above 0.")
            if target_points < 0:
                raise TradeError("Target points cannot be negative.")
            if not dry:
                ok, why = self._in_hours(dry)
                if not ok:
                    raise TradeError(why)
                if not confirm_live:
                    raise TradeError("LIVE order needs confirmation.")
            elif s["enforce_hours"]:
                ok, why = self._in_hours(dry)
                if not ok:
                    raise TradeError(why + " (turn off 'Enforce market hours' to test in dry-run.)")
            if s["max_daily_loss"] and self.day_pnl(dry) <= -s["max_daily_loss"]:
                raise TradeError("Daily loss limit Rs %d reached - no new entries today." % s["max_daily_loss"])
            c = self.get_contract(underlying)
            qty = lots * c["lot_size"]
            order_id = None
            try:
                if dry:
                    last, bid, ask = self.quote(c)
                    fill = (ask if (side == "BUY" and ask > 0) else bid if (side == "SELL" and bid > 0) else last)
                else:
                    req, avail = self._margin_check(c, side, qty)
                    self.log("LIVE %s %d x %s (margin Rs %.0f of Rs %.0f)" % (side, qty, c["tradingsymbol"], req, avail))
                    order_id = self._place(c, side, qty)
                    fill = self._confirm_fill(order_id)
            except TradeError:
                raise
            except Exception as exc:   # noqa: BLE001
                self._auth_failed(exc)
                raise TradeError("Order failed: %s" % exc)
            sgn = 1 if side == "BUY" else -1
            tick = c["tick_size"] or 0.05
            r = lambda x: round(round(x / tick) * tick, 2)
            pos = {
                "id": uuid.uuid4().hex[:8], "underlying": underlying, "exchange": c["exchange"],
                "tradingsymbol": c["tradingsymbol"], "side": side, "lots": lots, "lot_size": c["lot_size"],
                "qty": qty, "entry": fill, "sl": r(fill - sgn * sl_points),
                "target": (r(fill + sgn * target_points) if target_points > 0 else None),
                "sl_points": sl_points, "target_points": target_points, "best": fill, "last": fill,
                "entry_time": now().isoformat(timespec="seconds"), "dry_run": dry, "order_id": order_id,
                "trailing": s["trailing"], "trail_start": s["trail_start"], "trail_gap": s["trail_gap"],
                "exit_error": None,
            }
            with self.lock:
                self.position = pos
                self._reconciled = True
                self._save_state()
            self.log("%s ENTRY %s %d x %s @ %.2f | SL %.2f | target %s%s" % (
                "DRY" if dry else "LIVE", side, qty, c["tradingsymbol"], fill, pos["sl"], pos["target"],
                " | trailing on" if pos["trailing"] else ""))
            return pos

    def close_position(self, reason="MANUAL", price_hint=None):
        with self.op_lock:
            pos = self.position
            if not pos:
                raise TradeError("No open position.")
            c = {"exchange": pos["exchange"], "tradingsymbol": pos["tradingsymbol"], "tick_size": 0.05}
            opp = "SELL" if pos["side"] == "BUY" else "BUY"
            try:
                if pos["dry_run"]:
                    try:
                        last, bid, ask = self.quote(c)
                        fill = (bid if (opp == "SELL" and bid > 0) else ask if (opp == "BUY" and ask > 0) else last)
                    except Exception:  # noqa: BLE001
                        fill = price_hint if price_hint else pos["last"]
                else:
                    if not self.logged_in:
                        raise TradeError("Not logged in - cannot send the exit order.")
                    oid = self._place(c, opp, pos["qty"])
                    fill = self._confirm_fill(oid)
            except TradeError as exc:
                pos["exit_error"] = str(exc)
                self._save_state()
                self.log("!!! EXIT FAILED (%s): %s" % (reason, exc))
                raise
            except Exception as exc:   # noqa: BLE001
                self._auth_failed(exc)
                pos["exit_error"] = str(exc)
                self._save_state()
                self.log("!!! EXIT FAILED (%s): %s" % (reason, exc))
                raise TradeError("Exit failed: %s" % exc)
            return self._record_exit(pos, fill, reason)

    def _record_exit(self, pos, fill, reason):
        sgn = 1 if pos["side"] == "BUY" else -1
        pts = round((fill - pos["entry"]) * sgn, 2)
        rec = dict(pos)
        rec.update({"exit": fill, "exit_time": now().isoformat(timespec="seconds"), "exit_reason": reason,
                    "pnl_points": pts, "pnl_rupees": round(pts * pos["qty"], 2)})
        with self.lock:
            self.trades.append(rec)
            self.position = None
            self._save_trades()
            self._save_state()
        self.log("%s EXIT %s %s @ %.2f (%s) | %+.2f pts = Rs %+.2f (before charges)" % (
            "DRY" if pos["dry_run"] else "LIVE", pos["side"], pos["tradingsymbol"], fill, reason,
            pts, rec["pnl_rupees"]))
        return rec

    # ------------------------------------------------------------------ monitor
    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop = False
        self._thread = threading.Thread(target=self._loop, daemon=True, name="futures-monitor")
        self._thread.start()

    def stop(self):
        self._stop = True

    def _reconcile(self):
        """After a restart: a LIVE position that no longer exists at Zerodha is closed in the journal."""
        pos = self.position
        if not pos or pos.get("dry_run"):
            self._reconciled = True
            return
        try:
            self._throttle()
            net = self.kite.positions().get("net", [])
            qty = 0
            for p in net:
                if p.get("tradingsymbol") == pos["tradingsymbol"] and p.get("product") == "MIS":
                    qty = int(p.get("quantity", 0))
            want = pos["qty"] if pos["side"] == "BUY" else -pos["qty"]
            if qty == want:
                self.log("Position matches Zerodha - monitoring resumed.")
            elif qty == 0:
                self.log("Position is no longer open at Zerodha (closed there?). Recorded as closed.")
                self._record_exit(pos, pos.get("last", pos["entry"]), "CLOSED_ELSEWHERE")
            else:
                self.warn = "Zerodha net qty %d differs from this app's %d - check Kite." % (qty, want)
                self.log("!!! " + self.warn)
            self._reconciled = True
        except Exception as exc:       # noqa: BLE001
            self._auth_failed(exc)
            self.log("Reconcile failed (will retry): %s" % exc)

    def _loop(self):
        fails = 0
        while not self._stop:
            try:
                if not self.logged_in:
                    time.sleep(1.0)
                    continue
                if self.position and not self._reconciled:
                    self._reconcile()
                    if not self._reconciled:
                        time.sleep(3)
                        continue
                pos = self.position
                if pos:
                    c = {"exchange": pos["exchange"], "tradingsymbol": pos["tradingsymbol"]}
                else:
                    c = self.get_contract(self.settings["underlying"])
                price = self.ltp(c)
                fails = 0
                self.price_ok_at = time.time()
                if (self.warn or "").startswith("Price feed"):
                    self.warn = None
                self.preview = {"tradingsymbol": c["tradingsymbol"], "last": price, "at": now().strftime("%H:%M:%S")}
                if pos:
                    self._manage(price)
            except Exception as exc:   # noqa: BLE001
                fails += 1
                if self._auth_failed(exc):
                    time.sleep(2)
                    continue
                if fails in (1, 5, 20):
                    self.log("Price/monitor error (%d): %s" % (fails, exc))
                if self.position and time.time() - self.price_ok_at > 20:
                    self.warn = "Price feed lost for %ds - SL/target are NOT being checked!" % (time.time() - self.price_ok_at)
                if os.environ.get("KPF_DEBUG"):
                    traceback.print_exc()
                time.sleep(2)

    def _manage(self, price):
        with self.op_lock:
            pos = self.position
            if not pos:
                return
            with self.lock:
                pos["last"] = price
                sgn = 1 if pos["side"] == "BUY" else -1
                # best favourable price + trailing stop (only ever tightens)
                if (price - pos["best"]) * sgn > 0:
                    pos["best"] = price
                if pos.get("trailing") and (pos["best"] - pos["entry"]) * sgn >= pos["trail_start"]:
                    new_sl = pos["best"] - sgn * pos["trail_gap"]
                    if (new_sl - pos["sl"]) * sgn > 0:
                        pos["sl"] = round(new_sl, 2)
                        pos["trailed"] = True
                reason = None
                if (price - pos["sl"]) * sgn <= 0:
                    reason = "TRAILING_SL" if pos.get("trailed") else "SL"
                elif pos.get("target") is not None and (price - pos["target"]) * sgn >= 0:
                    reason = "TARGET"
                elif now().time() >= _hhmm(self.settings["force_exit_time"], "15:15"):
                    reason = "FORCE_EXIT"
            if reason:
                self.log("%s triggered at %.2f" % (reason, price))
                try:
                    self.close_position(reason, price_hint=price)
                except Exception:      # noqa: BLE001 - already logged; retried on the next tick
                    time.sleep(2)
            else:
                self._save_state()

    # ------------------------------------------------------------------ snapshot for the UI
    def snapshot(self):
        with self.lock:
            pos = dict(self.position) if self.position else None
            if pos:
                sgn = 1 if pos["side"] == "BUY" else -1
                pos["pnl_points"] = round((pos["last"] - pos["entry"]) * sgn, 2)
                pos["pnl_rupees"] = round(pos["pnl_points"] * pos["qty"], 2)
            dry = self.settings["dry_run"]
            today = now().strftime("%Y-%m-%d")
            todays = [t for t in self.trades if str(t.get("exit_time", ""))[:10] == today and bool(t.get("dry_run")) == bool(dry)]
            c = self.contract.get(self.settings["underlying"])
            return {
                "time": now().strftime("%H:%M:%S"),
                "settings": self.public_settings(),
                "logged_in": self.logged_in, "user": self.user, "login_error": self.login_error,
                "has_kite": KiteConnect is not None,
                "contract": ({k: v for k, v in c.items() if not k.startswith("_")} if c else None),
                "preview": self.preview, "position": pos, "warn": self.warn,
                "day_pnl": round(self.day_pnl(dry), 2), "day_trades": len(todays),
                "trades": list(reversed(self.trades[-30:])), "logs": list(self.logs)[-60:],
                "underlyings": UNDERLYINGS, "suggested": SUGGESTED,
            }
