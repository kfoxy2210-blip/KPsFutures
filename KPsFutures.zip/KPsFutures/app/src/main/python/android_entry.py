"""
Android entry point for KP's Futures (called from AlgoService through Chaquopy).
Runs app.py's dashboard exactly as `python app.py` does on a PC, with these adjustments only:
  * working folder = the app's private folder (settings.json, token, journal live there)
  * "open the browser" is redirected to the in-app WebView (Zerodha login)
  * clocks are pinned to IST
"""
import os
import sys
import time
import traceback


def _pin_ist():
    for name in ("Asia/Kolkata", "IST-5:30", "Asia/Calcutta"):
        os.environ["TZ"] = name
        try:
            time.tzset()
        except Exception:                # noqa: BLE001
            continue
        if time.localtime().tm_gmtoff == 19800:
            break
    print("[android_entry] clock: %s (UTC%+d min) TZ=%s" % (
        time.strftime("%H:%M:%S"), time.localtime().tm_gmtoff // 60, os.environ.get("TZ")))


def _patch_browser():
    import webbrowser
    try:
        from java import jclass          # only exists inside Chaquopy
        bridge = jclass("com.algoai.trader.Bridge")

        def _open(url, new=0, autoraise=True):
            bridge.openUrl(str(url))
            return True
    except Exception:                    # noqa: BLE001
        def _open(url, new=0, autoraise=True):
            print("[android_entry] open this URL:", url)
            return True
    webbrowser.open = _open
    webbrowser.open_new = _open
    webbrowser.open_new_tab = _open


def start(app_dir, port=5054):
    """Blocks for as long as the dashboard server runs. Run it in a background thread."""
    _pin_ist()
    os.chdir(app_dir)
    if app_dir not in sys.path:
        sys.path.insert(0, app_dir)
    _patch_browser()
    try:
        import app as futures_app
        futures_app.PORT = int(port)
        futures_app.main(open_browser=False)
    except BaseException:                # noqa: BLE001 - SystemExit too, so the UI can show why
        traceback.print_exc()
        try:
            with open(os.path.join(app_dir, "android_error.txt"), "w") as f:
                f.write(traceback.format_exc())
        except Exception:                # noqa: BLE001
            pass
        raise
