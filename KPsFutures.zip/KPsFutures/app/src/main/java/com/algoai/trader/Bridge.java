package com.algoai.trader;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** Small glue between the Python engine and the Android UI. Python calls openUrl(). */
public final class Bridge {
    static final String ALERT_CHANNEL = "algo_alerts";

    static volatile MainActivity activity;     // set while MainActivity exists
    static volatile Context appContext;        // set by AlgoService
    static volatile String pendingUrl;         // page the UI should show next (e.g. Zerodha login)

    private Bridge() {}

    /** Called from Python (webbrowser.open is redirected here). Thread-safe. */
    public static void openUrl(final String url) {
        pendingUrl = url;
        final MainActivity a = activity;
        if (a != null && a.isUiVisible()) {
            a.runOnUiThread(new Runnable() {
                @Override public void run() { a.consumePendingUrl(); }
            });
        } else {
            notifyOpen("Zerodha login ready", "Tap to open the login page");
        }
    }

    static void notifyOpen(String title, String text) {
        Context c = appContext;
        if (c == null) return;
        try {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(
                    ALERT_CHANNEL, "Alerts", NotificationManager.IMPORTANCE_HIGH));
            Intent i = new Intent(c, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PendingIntent pi = PendingIntent.getActivity(c, 7, i,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(c, ALERT_CHANNEL)
                    .setSmallIcon(R.drawable.ic_notify)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify(2, n);
        } catch (Exception ignored) {
            // notification permission may be denied - nothing else we can do
        }
    }
}
