package com.algoai.trader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Full-screen WebView onto the local dashboard (http://127.0.0.1:5050). */
public class MainActivity extends Activity {
    static final String DASH = "http://127.0.0.1:" + AlgoService.PORT + "/";
    private static final int REQ_NOTIF = 11;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private WebView web;
    private TextView status;
    private volatile boolean alive = true;
    private boolean resumed = false;
    private boolean loginShown = false;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.parseColor("#F2F2F2"));

        web = new WebView(this);
        configureWebView(web);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        status = new TextView(this);
        status.setText("Starting trading engine...\n(first start can take 10-20 seconds)");
        status.setTextSize(16);
        status.setTextColor(Color.parseColor("#344054"));
        status.setGravity(Gravity.CENTER);
        status.setPadding(48, 48, 48, 48);
        root.addView(status, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
        Bridge.activity = this;

        startEngineService();
        askNotificationPermissionThenBattery();
        waitForServerThenLoad();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        Bridge.activity = this;
        startEngineService();      // re-arms the wake lock and revives the service if needed
        consumePendingUrl();
    }

    @Override
    protected void onPause() {
        resumed = false;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        alive = false;
        if (Bridge.activity == this) Bridge.activity = null;
        try {
            root.removeAllViews();
            web.destroy();
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        String cur = web != null ? web.getUrl() : null;
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else if (web != null && (cur == null || !cur.startsWith(DASH))) {
            loginShown = false;
            web.loadUrl(DASH);      // e.g. leaving the Zerodha login page
        } else {
            moveTaskToBack(true);      // never close: the engine keeps running in the background
        }
    }

    boolean isUiVisible() { return resumed; }

    /** Shows a page requested by Python (the Zerodha login page). Must run on the UI thread. */
    void consumePendingUrl() {
        String url = Bridge.pendingUrl;
        if (url == null || url.length() == 0) return;
        Bridge.pendingUrl = null;
        loginShown = true;
        status.setVisibility(View.GONE);
        web.loadUrl(url);
    }

    // ------------------------------------------------------------------ engine service

    private void startEngineService() {
        try {
            Intent i = new Intent(this, AlgoService.class);
            startForegroundService(i);
        } catch (Exception e) {
            Toast.makeText(this, "Could not start background service: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        }
    }

    private void waitForServerThenLoad() {
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                final long begin = System.currentTimeMillis();
                while (alive) {
                    if (ping()) {
                        ui.post(new Runnable() {
                            @Override public void run() {
                                if (!alive) return;
                                if (Bridge.pendingUrl != null) {
                                    consumePendingUrl();
                                } else if (!loginShown) {
                                    status.setVisibility(View.GONE);
                                    web.loadUrl(DASH);
                                }
                            }
                        });
                        return;
                    }
                    final long secs = (System.currentTimeMillis() - begin) / 1000;
                    if (secs > 30) {
                        final String err = readFailure();
                        ui.post(new Runnable() {
                            @Override public void run() {
                                if (alive && status.getVisibility() == View.VISIBLE) {
                                    status.setText(err != null
                                            ? "The engine could not start:\n\n" + err
                                            : "Still starting... (" + secs + "s)");
                                }
                            }
                        });
                    }
                    try { Thread.sleep(800); } catch (InterruptedException e) { return; }
                }
            }
        }, "wait-for-server");
        t.start();
    }

    private boolean ping() {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(DASH).openConnection();
            c.setConnectTimeout(800);
            c.setReadTimeout(2500);
            int code = c.getResponseCode();
            return code >= 200 && code < 500;
        } catch (Exception e) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private String readFailure() {
        try {
            File f = new File(new File(getFilesDir(), "algo_ai"), "android_error.txt");
            if (f.exists()) {
                String s = new String(java.nio.file.Files.readAllBytes(f.toPath()));
                return s.length() > 1500 ? s.substring(s.length() - 1500) : s;
            }
        } catch (Exception ignored) {
        }
        String e = AlgoService.lastError;
        if (e != null) return e.length() > 1500 ? e.substring(0, 1500) : e;
        return null;
    }

    // ------------------------------------------------------------------ permissions

    private void askNotificationPermissionThenBattery() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        } else {
            askBatteryExemption();
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_NOTIF) askBatteryExemption();
    }

    private void askBatteryExemption() {
        try {
            final PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            SharedPreferences prefs = getSharedPreferences("algo", MODE_PRIVATE);
            if (pm.isIgnoringBatteryOptimizations(getPackageName())) return;
            if (prefs.getBoolean("battery_asked", false)) return;
            prefs.edit().putBoolean("battery_asked", true).apply();
            new AlertDialog.Builder(this)
                    .setTitle("Keep running in background")
                    .setMessage("For stop-loss and square-off to work while the screen is off, "
                            + "allow this app to run without battery restrictions on the next screen.")
                    .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            try {
                                Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                        Uri.parse("package:" + getPackageName()));
                                startActivity(i);
                            } catch (Exception ignored) {
                            }
                        }
                    })
                    .setNegativeButton("Later", null)
                    .show();
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ WebView

    private void configureWebView(final WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);   // always the freshest dashboard code
        s.setBuiltInZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true);

        w.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                String u = r.getUrl().toString();
                if (u.startsWith("http://") || u.startsWith("https://")) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl()));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                if (url == null) return;
                // Kite redirects to http://127.0.0.1:5000/?request_token=... which the engine
                // catches itself. Once that page is shown, go back to the dashboard.
                if (url.startsWith("http://127.0.0.1:5000")) {
                    ui.postDelayed(new Runnable() {
                        @Override public void run() {
                            if (!alive) return;
                            loginShown = false;
                            web.loadUrl(DASH);
                        }
                    }, 1800);
                }
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame() && r.getUrl().toString().startsWith("http://127.0.0.1:" + AlgoService.PORT)) {
                    ui.postDelayed(new Runnable() {
                        @Override public void run() { if (alive) web.loadUrl(DASH); }
                    }, 2500);
                }
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                ui.post(new Runnable() {
                    @Override public void run() { if (alive) recreate(); }
                });
                return true;
            }
        });

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView v, String url, String message, final JsResult result) {
                if (isFinishing()) { result.cancel(); return true; }
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int x) { result.confirm(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface d) { result.cancel(); }
                        })
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String message, final JsResult result) {
                if (isFinishing()) { result.cancel(); return true; }
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int x) { result.confirm(); }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int x) { result.cancel(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface d) { result.cancel(); }
                        })
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView v, String url, String message, String def,
                                      final JsPromptResult result) {
                if (isFinishing()) { result.cancel(); return true; }
                final EditText input = new EditText(MainActivity.this);
                input.setText(def);
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setView(input)
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int x) {
                                result.confirm(input.getText().toString());
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface d, int x) { result.cancel(); }
                        })
                        .setOnCancelListener(new DialogInterface.OnCancelListener() {
                            @Override public void onCancel(DialogInterface d) { result.cancel(); }
                        })
                        .show();
                return true;
            }

            // window.open / target=_blank -> load in this same WebView
            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                final WebView temp = new WebView(MainActivity.this);
                temp.setWebViewClient(new WebViewClient() {
                    private boolean handled = false;
                    private void forward(WebView t, String url) {
                        if (handled || url == null || url.equals("about:blank")) return;
                        handled = true;
                        web.loadUrl(url);
                        t.destroy();
                    }
                    @Override
                    public boolean shouldOverrideUrlLoading(WebView t, WebResourceRequest r) {
                        forward(t, r.getUrl().toString());
                        return true;
                    }
                    @Override
                    public void onPageStarted(WebView t, String url, android.graphics.Bitmap icon) {
                        forward(t, url);
                    }
                });
                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(temp);
                resultMsg.sendToTarget();
                return true;
            }
        });

        w.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String ua, String disposition, String mime, long len) {
                saveDownload(url, disposition, mime);
            }
        });
    }

    /** Saves a file served by the local dashboard (e.g. trades CSV) into the Downloads folder. */
    private void saveDownload(final String url, final String disposition, final String mime) {
        if (url == null || !url.startsWith("http://127.0.0.1:")) return;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final String name = URLUtil.guessFileName(url, disposition, mime);
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(3000);
                    c.setReadTimeout(20000);
                    InputStream in = c.getInputStream();
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mime != null && mime.length() > 0 ? mime : "text/csv");
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) throw new Exception("could not create file");
                    OutputStream out = getContentResolver().openOutputStream(uri);
                    byte[] buf = new byte[16384];
                    int r;
                    while ((r = in.read(buf)) > 0) out.write(buf, 0, r);
                    out.close();
                    in.close();
                    c.disconnect();
                    ui.post(new Runnable() {
                        @Override public void run() {
                            Toast.makeText(MainActivity.this, "Saved to Downloads: " + name,
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (final Exception e) {
                    ui.post(new Runnable() {
                        @Override public void run() {
                            Toast.makeText(MainActivity.this, "Download failed: " + e.getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }
}
