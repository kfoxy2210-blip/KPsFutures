# KP's Futures

Index and stock FUTURES trading (NIFTY / BANKNIFTY / SENSEX / ... or any F&O stock like RELIANCE): Buy or Sell, stop-loss + target in points,
optional trailing stop, force-exit time, daily-loss limit. **Dry-run is ON by default** (simulated at live bid/ask).
Dashboard port 5054. Zerodha redirect URL: http://127.0.0.1:5000/

Run on a PC for testing: `pip install flask kiteconnect` then `python app.py` (dashboard opens at http://127.0.0.1:5054).
No licence module - this is a separate, plain-Python app (not part of the protected KP engine).
